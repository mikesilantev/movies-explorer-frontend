// const heightPromoContainer = document.querySelector('.promo');

// export {
//   heightPromoContainer
// };